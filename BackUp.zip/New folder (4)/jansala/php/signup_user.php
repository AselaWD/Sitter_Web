<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ha07";
$user_name=$_POST['User_name'];
$user_password=$_POST['user_password'];
$user_verify_password=$_POST['user_verify_password'];
$user1_first_name=$_POST['user_firstname'];
$user_last_name=$_POST['user_last_name'];
$user_gender=$_POST['user_gender'];
$user_birthday=$_POST['user_birthday'];
$user_address=$_POST['user_address'];
$user_email=$_POST['user_mail'];
$user_contact=$_POST['user_contact'];

echo"$user1_first_name";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO usr_table (usrnme,password,Firstnme,LastNme,Gender,Birthday,Address,EMail,Contact)
VALUES ('$user_name','$user_password','$user1_first_name','$user_last_name','$user_gender','$user_birthday','$user_address','$user_email','$user_contact')";

if ($conn->query($sql) === TRUE) {
   echo "New record created successfully";
} else {
   echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
