<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ha07";
$user_name=$_POST['user_name'];
$user_password=$_POST['user_password'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT usrnme,password FROM str_table";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $check_username=$row['usrnme'];
        $check_password=$row['password'];
        if($user_name==$check_username AND $user_password==$check_password){
          //echo"$check_username <br> $check_password";
          header('location:profile.php');
        }else {

          echo"invalid password or username";
        }
    }
} else {
    echo "0 results";
  }
$conn->close();
?>
