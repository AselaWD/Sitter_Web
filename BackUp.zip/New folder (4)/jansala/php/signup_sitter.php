<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ha07";
$sitter_username=$_POST['sitter_username'];
$sitter_password=$_POST['sitter_password'];
$sitter_verify_password=$_POST['sitter_verify_password'];
$sitter_service_type=$_POST['service_type'];
$sitter_first_name=$_POST['sitter_first_name'];
$sitter_last_name=$_POST['sitter_last_name'];
$sitter_gender=$_POST['Gender'];
$sitter_birthday=$_POST['sitter_birthday'];
$sitter_address=$_POST['sitter_address'];
$sitter_email=$_POST['sitter_email'];
$sitter_contact=$_POST['sitter_contact'];


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO str_table (usrnme,password,SrviceType,Firstnme,LastNme,Gender,Birthday,Address,EMail,Contact)
VALUES ('$sitter_username','$sitter_password','$sitter_service_type','$sitter_first_name','$sitter_last_name','$sitter_gender','$sitter_birthday','$sitter_address','$sitter_email','$sitter_contact')";

if ($conn->query($sql) === TRUE) {
   echo "New record created successfully";
} else {
   echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
